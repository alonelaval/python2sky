# -*- coding:utf-8 -*-
# author：huawei

def skywalking_boot():
    import python2sky.remote.service_register_client
    import python2sky.remote.trace_segment_client
