# -*- coding:utf-8 -*-
# author：huawei

class SkywalkingException(BaseException):
    pass